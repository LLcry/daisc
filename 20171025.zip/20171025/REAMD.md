## 做完这个项目能学到什么   难度 初级
    h5+ccs3 + jquery  + animate.css


## 做完这个项目能找到前端开发的工作

   1.女孩子有可能  4000




## vue.js  +  小程序 + node.js    5000起


1.node.js  写后台   做为后台和前端的 中间件 来提高效率

2.vue react  ng  + webpack 也可以用上node  还有很多强大

3.现在很多公司的桌面应用，手机应用，手表应用  都是用Node

4.很多硬件 有专门的 node 接口

